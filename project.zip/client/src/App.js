// // import { Route, Routes, Navigate } from "react-router-dom";
// import { BrowserRouter as Router, Routes, Route,Navigate } from "react-router-dom";
// import Main from "./components/Main";
// import Login from "./components/Login";
// import Signup from "./components/Signup";

// function App() {
// 	const user = localStorage.getItem("token");

// 	return (
// 		<Routes>
// 			{user && <Route path="/" exact element={<Main />} />}
// 			<Route path="/login" exact element={<Login />} />
// 			<Route path="/signup" exact element={<Signup/>}/>
// 			        <Route path="/contacts" element={<ContactManager />} />

// 			<Route path="/" element={<Navigate replace to="/login" />} />
// 		</Routes>
// 	);
// }

// export default App;

import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import Main from "./components/Main";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Navbar from "./components/navbar";
import ContactManager from "./components/contact";
import Global_contact from "./components/Global_contact";
import "./App.css"; // ✅ Import the global styles

function App() {
  const user = localStorage.getItem("token");
  const location = useLocation();
  const hideNavbar = location.pathname === "/login" || location.pathname === "/signup";

  return (
    <div className="appContainer">
      {!hideNavbar && <Navbar />}
      
      {/* ✅ Background Wrapper to contain the full background */}
      <div className="contentWrapper">
        <Routes>
          {user ? (
            <>
              <Route path="/" element={<Main />} />
              <Route path="/contacts" element={<ContactManager />} />
              <Route path="/Global_contact" element={<Global_contact/>}/>
              <Route path="*" element={<Navigate replace to="/" />} /> {/* Redirect unknown routes */}
            </>
          ) : (
            <Route path="/" element={<Navigate replace to="/login" />} />
          )}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="*" element={<Navigate replace to="/login" />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
