import axios from "axios";

const API_URL = "http://localhost:5000/api/contacts";

// Fetch JWT token from localStorage
const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    return {
        headers: { Authorization: `Bearer ${token}` },
    };
};

// Fetch all contacts
export const fetchContacts = async () => {
    return await axios.get(`${API_URL}/fetch`, getAuthHeaders());
};

// export const fetchContacts = async () => {
//     try {
//         const response = await axios.get(`${API_URL}/all`, getAuthHeaders());
//         console.log("Fetched Contacts:", response.data);
//         return response.data;
//     } catch (error) {
//         console.error("Error fetching contacts:", error.response?.data || error.message);
//         throw error; // Re-throw for handling in React components
//     }
// };


// Create a new contact
// exp+ort const createContact = async (contactData) => {
//     return await axios.post(`${API_URL}/createNew`, contactData, getAuthHeaders());
// };
export const createContact = async (contactData) => {
    return await axios.post(`${API_URL}/create`, contactData, getAuthHeaders());
};



// Update a contact
// export const updateContact = async (id, contactData) => {
//     return await axios.put(`${API_URL}/${id}`, contactData, getAuthHeaders());
// };


export const updateContact = async (id, contactData) => {
    console.log("Updating Contact:", id, contactData);
    
    return await axios.put(`${API_URL}/update/${id}`, contactData, getAuthHeaders());
};





// Delete a contact
export const deleteContact = async (id) => {
    return await axios.delete(`${API_URL}/delete/${id}`, getAuthHeaders());
};


// export const fetchGlobalContacts = async () => {
//     return await axios.get(`${API_URL}/global`, getAuthHeaders());
// };

export const fetchGlobalContacts = async () => {
    try {
        const response = await axios.get(`${API_URL}/all`, getAuthHeaders());
        console.log("Fetched Global Contacts:", response.data); // Debugging
        return response;
    } catch (error) {
        console.error("Error fetching global contacts:", error.response?.data || error.message);
        throw error;
    }
};
